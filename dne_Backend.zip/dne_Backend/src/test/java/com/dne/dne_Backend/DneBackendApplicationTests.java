package com.dne.dne_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DneBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
