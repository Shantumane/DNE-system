package com.dne.dne_Backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Quiz;
import com.dne.dne_Backend.services.QuizService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class QuizController {

	@Autowired
    private QuizService quizService;

    @PostMapping("/quizs")
    public void addQuiz(@RequestBody Quiz quiz) {
    	quizService.addQuiz(quiz);
    }

    @PutMapping("/{quizId}")
    public void updateUser(@PathVariable int quizId, @RequestBody Quiz quiz) {
    	quiz.setQuizId(quizId);
        quizService.UpdateQuiz(quiz);
    }

    @DeleteMapping("/{quizId}")
    public void deleteQuiz(@PathVariable int quizId) {
    	quizService.deleteQuiz(quizId);
    }

    @GetMapping("/{quizId}")
    public Quiz getQuizById(@PathVariable int quizId) {
        return quizService.getQuizById(quizId);
    }

    @GetMapping("/quiz")
    public List<Quiz> getAllQuizs() {
        return quizService.getAllQuiz();
    }
}
