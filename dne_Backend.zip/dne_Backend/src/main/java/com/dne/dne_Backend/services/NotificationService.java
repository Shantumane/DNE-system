package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Notification;
import com.dne.dne_Backend.repository.NotificationRepository;



@Service
public class NotificationService {

	@Autowired

	private NotificationRepository notificationRepository;
	
	public List<Notification> getAllNotification(){
		return notificationRepository.findAll();
	}

	public Notification addNotification(Notification notification) {
		return notificationRepository.save(notification);
	}
	
	public void UpdateNotification(Notification notification) {
		notificationRepository.save(notification);
	}
	
	public void deleteNotification(int notificationId) {
		notificationRepository.deleteById(notificationId);
	}
	
	public Notification getNotificationById(int notificationId) {
		return notificationRepository.findById(notificationId).orElse(null);
	}
	
	public List<Notification> getAllNotifications(){
		return notificationRepository.findAll();
	}
	
	

}
