package com.dne.dne_Backend.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Grade {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int gradeId;
	private int courseId;
	private int studentId;
	private int assignmentId;
	private double gradeValue;
	
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}
	public double getGradeValue() {
		return gradeValue;
	}
	public void setGradeValue(double gradeValue) {
		this.gradeValue = gradeValue;
	}
	public Grade(int gradeId, int courseId, int studentId, int assignmentId, double gradeValue) {
		this.gradeId = gradeId;
		this.courseId = courseId;
		this.studentId = studentId;
		this.assignmentId = assignmentId;
		this.gradeValue = gradeValue;
	}
	public Grade() {
		
	}
	
	

}
