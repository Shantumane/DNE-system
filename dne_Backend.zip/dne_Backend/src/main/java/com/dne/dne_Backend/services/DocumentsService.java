package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Documents;
import com.dne.dne_Backend.repository.DocumentsRepository;



@Service
public class DocumentsService {
	
	@Autowired
	
	private DocumentsRepository documentsRepository;
	
	public List<Documents> getAllDocument(){
		return documentsRepository.findAll();
	}

	public Documents addDocuments(Documents documents) {
		return documentsRepository.save(documents);
	}
	
	public void UpdateDocuments(Documents documents) {
		documentsRepository.save(documents);
	}
	
	public void deleteDocuments(int documentsId) {
		documentsRepository.deleteById(documentsId);
	}
	
	public Documents getDocumentsById(int documentsId) {
		return documentsRepository.findById(documentsId).orElse(null);
	}
	
	public List<Documents> getAllDocuments(){
		return documentsRepository.findAll();
	}

}
