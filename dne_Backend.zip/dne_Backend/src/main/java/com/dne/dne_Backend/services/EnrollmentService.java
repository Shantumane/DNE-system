package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Enrollment;
import com.dne.dne_Backend.repository.EnrollmentRepository;



@Service
public class EnrollmentService {

	@Autowired
	private EnrollmentRepository enrollmentRepository;
	
	public List<Enrollment> getAllEnrollment(){
		return enrollmentRepository.findAll();
	}

	public Enrollment addEnrollment(Enrollment enrollment) {
		return enrollmentRepository.save(enrollment);
	}
	
	public void UpdateEnrollment(Enrollment enrollment) {
		enrollmentRepository.save(enrollment);
	}
	
	public void deleteEnrollment(int enrollmentId) {
		enrollmentRepository.deleteById(enrollmentId);
	}
	
	public Enrollment getEnrollmentById(int enrollmentId) {
		return enrollmentRepository.findById(enrollmentId).orElse(null);
	}
	
	public List<Enrollment> getAllEnrollments(){
		return enrollmentRepository.findAll();
	}
}
