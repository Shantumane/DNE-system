package com.dne.dne_Backend.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.User;
import com.dne.dne_Backend.entity.UserLoginRequest;
import com.dne.dne_Backend.entity.UserRegisterRequest;
import com.dne.dne_Backend.repository.UserRepository;




@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;

    // Login method
    public ResponseEntity<String> login(UserLoginRequest loginRequest) {
        // Retrieve user by username
        User user = userRepository.findByUserName(loginRequest.getUserName());

        if (user != null && user.getPassword().equals(loginRequest.getPassword())) {
            return new ResponseEntity<>("Login successful", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid username or password", HttpStatus.UNAUTHORIZED);
        }
    }

    // Registration method
    public ResponseEntity<String> register(UserRegisterRequest registerRequest) {
        // Check if username already exists
        if (userRepository.existsByUserName(registerRequest.getUserName())) {
            return new ResponseEntity<>("Username already exists", HttpStatus.BAD_REQUEST);
        }

        // Create new user
        User user = new User();
        user.setUserName(registerRequest.getUserName());
        user.setEmail(registerRequest.getEmail());
        user.setPassword(registerRequest.getPassword());

        // Save user to database
        userRepository.save(user);

        return new ResponseEntity<>("Registration successful", HttpStatus.CREATED);
    }
}