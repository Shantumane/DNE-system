package com.dne.dne_Backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Notification;
import com.dne.dne_Backend.services.NotificationService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class NotificationController {

	@Autowired
    private NotificationService notificationService;

    @PostMapping("/notifications")
    public void addNotification(@RequestBody Notification notification) {
    	notificationService.addNotification(notification);
    }

    @PutMapping("/{notificationId}")
    public void updateNotification(@PathVariable int notificationId, @RequestBody Notification notification) {
    	notification.setNotificationId(notificationId);
        notificationService.UpdateNotification(notification);
    }

    @DeleteMapping("/{notificationId}")
    public void deleteUser(@PathVariable int notificationId) {
    	notificationService.deleteNotification(notificationId);
    }

    @GetMapping("/{notificationId}")
    public Notification getNotificationById(@PathVariable int notificationId) {
        return notificationService.getNotificationById(notificationId);
    }

    @GetMapping("/notification")
    public List<Notification> getAllNotifications() {
        return notificationService.getAllNotifications();
    }
}
