package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Resource;
import com.dne.dne_Backend.repository.ResourceRepository;



@Service
public class ResourceService {

	@Autowired
	private ResourceRepository resourceRepository;
	
	public List<Resource> getAllCourse(){
		return resourceRepository.findAll();
	}

	public Resource addResource(Resource resource) {
		return resourceRepository.save(resource);
	}
	
	public void UpdateResource(Resource resource) {
		resourceRepository.save(resource);
	}
	
	public void deleteResource(int resourceId) {
		resourceRepository.deleteById(resourceId);
	}
	
	public Resource getResourceById(int resourceId) {
		return resourceRepository.findById(resourceId).orElse(null);
	}
	
	public List<Resource> getAllresource(){
		return resourceRepository.findAll();
	}
}
