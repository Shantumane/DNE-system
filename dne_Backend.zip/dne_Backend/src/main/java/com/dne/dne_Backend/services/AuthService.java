package com.dne.dne_Backend.services;

public interface AuthService {
	
	String login(String username, String password);

}
