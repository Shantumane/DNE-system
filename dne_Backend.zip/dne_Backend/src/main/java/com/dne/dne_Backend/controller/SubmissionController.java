package com.dne.dne_Backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Submission;
import com.dne.dne_Backend.services.SubmissionService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class SubmissionController {

	@Autowired
    private  SubmissionService submissionService;

    @PostMapping("/submissions")
    public void addUser(@RequestBody Submission submission) {
    	submissionService.addSubmission(submission);
    }

    @PutMapping("/{submissionId}")
    public void updateUser(@PathVariable int submissionId, @RequestBody Submission submission) {
    	submission.setSubmissionId(submissionId);
        submissionService.UpdateSubmission(submission);
    }

    @DeleteMapping("/{submissionId}")
    public void deleteUser(@PathVariable int submissionId) {
    	submissionService.deleteSubmission(submissionId);
    }

    @GetMapping("/{submissionId}")
    public Submission getUserById(@PathVariable int submissionId) {
        return submissionService.getSubmissionById(submissionId);
    }

    @GetMapping("/submission")
    public List<Submission> getAllUsers() {
        return submissionService.getAllSubmissions();
    }
}
