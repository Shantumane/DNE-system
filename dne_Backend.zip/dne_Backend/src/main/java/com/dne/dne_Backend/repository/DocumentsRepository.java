package com.dne.dne_Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dne.dne_Backend.entity.Documents;


@Repository
public interface DocumentsRepository extends JpaRepository<Documents, Integer> {

}
