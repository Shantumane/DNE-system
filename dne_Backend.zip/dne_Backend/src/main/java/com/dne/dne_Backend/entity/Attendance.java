package com.dne.dne_Backend.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Attendance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int attendanceId;
	private int courseId;
	private int studentId;
	private Date attendancedate;
	private String attendanceStatus;
	
	public int getAttendanceId() {
		return attendanceId;
	}
	public void setAttendanceId(int attendanceId) {
		this.attendanceId = attendanceId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public Date getAttendancedate() {
		return attendancedate;
	}
	public void setAttendancedate(Date attendancedate) {
		this.attendancedate = attendancedate;
	}
	public String getAttendanceStatus() {
		return attendanceStatus;
	}
	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}
	public Attendance(int attendanceId, int courseId, int studentId, Date attendancedate, String attendanceStatus) {
		this.attendanceId = attendanceId;
		this.courseId = courseId;
		this.studentId = studentId;
		this.attendancedate = attendancedate;
		this.attendanceStatus = attendanceStatus;
	}
	public Attendance() {
		
	}
	
	
	
	

}
