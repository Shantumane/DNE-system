package com.dne.dne_Backend.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class QuizAttempt {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int attemptId;
	private int quizId;
	private int studentId;
	private Date attemptDate;
	private int score;
	
	public int getAttemptId() {
		return attemptId;
	}
	public void setAttemptId(int attemptId) {
		this.attemptId = attemptId;
	}
	public int getQuizId() {
		return quizId;
	}
	public void setQuizId(int quizId) {
		this.quizId = quizId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public Date getAttemptDate() {
		return attemptDate;
	}
	public void setAttemptDate(Date attemptDate) {
		this.attemptDate = attemptDate;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public QuizAttempt(int attemptId, int quizId, int studentId, Date attemptDate, int score) {
		this.attemptId = attemptId;
		this.quizId = quizId;
		this.studentId = studentId;
		this.attemptDate = attemptDate;
		this.score = score;
	}
	public QuizAttempt() {
	}
	
	

}
