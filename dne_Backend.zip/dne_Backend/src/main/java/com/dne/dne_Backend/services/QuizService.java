package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Quiz;
import com.dne.dne_Backend.repository.QuizRepository;



@Service
public class QuizService {
	
	@Autowired
	
	private QuizRepository quizRepository;
	

	public List<Quiz> getAllQuiz(){
		return quizRepository.findAll();
	}

	public Quiz addQuiz(Quiz quiz) {
		return quizRepository.save(quiz);
	}
	
	public void UpdateQuiz(Quiz quiz) {
		quizRepository.save(quiz);
	}
	
	public void deleteQuiz(int quizId) {
		quizRepository.deleteById(quizId);
	}
	
	public Quiz getQuizById(int quizId) {
		return quizRepository.findById(quizId).orElse(null);
	}
	
	public List<Quiz> getAllquiz(){
		return quizRepository.findAll();
	}
	

}
