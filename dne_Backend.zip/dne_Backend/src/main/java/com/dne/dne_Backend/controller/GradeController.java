package com.dne.dne_Backend.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Grade;
import com.dne.dne_Backend.services.GradeService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class GradeController {

	@Autowired
    private GradeService gradeService;

    @PostMapping("/grades")
    public void addGrade(@RequestBody Grade grade) {
    	gradeService.addGrade(grade);
    }

    @PutMapping("/{gradeId}")
    public void updateGrade(@PathVariable int gradeId, @RequestBody Grade grade) {
    	grade.setGradeId(gradeId);
        gradeService.UpdateGrade(grade);
    }

    @DeleteMapping("/{gradeId}")
    public void deleteGrade(@PathVariable int gradeId) {
    	gradeService.deleteGrade(gradeId);
    }

    @GetMapping("/{gradeId}")
    public Grade getGradeById(@PathVariable int gradeId) {
        return gradeService.getGradeById(gradeId);
    }

    @GetMapping("/grade")
    public List<Grade> getAllGrades() {
        return gradeService.getAllGrades();
    }
}
