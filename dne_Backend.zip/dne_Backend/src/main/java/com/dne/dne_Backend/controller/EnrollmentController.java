package com.dne.dne_Backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Enrollment;
import com.dne.dne_Backend.services.EnrollmentService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class EnrollmentController {

	@Autowired
    private EnrollmentService enrollmentService;

    @PostMapping("/enrollments")
    public void addEnrollment(@RequestBody Enrollment enrollment) {
    	enrollmentService.addEnrollment(enrollment);
    }

    @PutMapping("/{enrollmentId}")
    public void updateEnrollment(@PathVariable int enrollmentId, @RequestBody Enrollment enrollment) {
    	enrollment.setEnrollmentId(enrollmentId);
        enrollmentService.UpdateEnrollment(enrollment);
    }

    @DeleteMapping("/{enrollmentId}")
    public void deleteEnrollment(@PathVariable int enrollmentId) {
    	enrollmentService.deleteEnrollment(enrollmentId);
    }

    @GetMapping("/{userId}")
    public Enrollment getEnrollmentById(@PathVariable int enrollmentId) {
        return enrollmentService.getEnrollmentById(enrollmentId);
    }

    @GetMapping("/enrollment")
    public List<Enrollment> getAllEnrollments() {
        return enrollmentService.getAllEnrollments();
    }
}
