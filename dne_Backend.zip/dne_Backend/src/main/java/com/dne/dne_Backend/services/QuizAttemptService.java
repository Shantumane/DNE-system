package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.QuizAttempt;
import com.dne.dne_Backend.repository.QuizAttemptRepository;




@Service
public class QuizAttemptService {

@Autowired
	
	private QuizAttemptRepository quizAttemptRepository;
	

	public List<QuizAttempt> getAllQuizAttempt(){
		return quizAttemptRepository.findAll();
	}

	public QuizAttempt addQuizAttempt(QuizAttempt quizAttempt) {
		return quizAttemptRepository.save(quizAttempt);
	}
	
	public void UpdateQuizAttempt(QuizAttempt quizAttempt) {
		quizAttemptRepository.save(quizAttempt);
	}
	
	public void deleteQuizAttempt(int quizAttemptId) {
		quizAttemptRepository.deleteById(quizAttemptId);
	}
	
	public QuizAttempt getQuizAttemptById(int quizAttemptId) {
		return quizAttemptRepository.findById(quizAttemptId).orElse(null);
	}
	
	public List<QuizAttempt> getAllQuizAttempts(){
		return quizAttemptRepository.findAll();
	}
}
