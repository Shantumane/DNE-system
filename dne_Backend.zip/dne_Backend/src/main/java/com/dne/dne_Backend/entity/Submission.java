package com.dne.dne_Backend.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "Submission")
public class Submission {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="submissionId")
	private int submissionId;
	@Column(name="assignmentId")
	private int assignmentId;
	@Column(name="StudentId")
	private int StudentId;
	@Column(name="submissionDate")
	private Date submissionDate;
	
	
	public int getSubmissionId() {
		return submissionId;
	}
	public void setSubmissionId(int submissionId) {
		this.submissionId = submissionId;
	}
	public int getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}
	public Submission(int submissionId, int assignmentId, int studentId, Date submissionDate) {
		super();
		this.submissionId = submissionId;
		this.assignmentId = assignmentId;
		StudentId = studentId;
		this.submissionDate = submissionDate;
	}
	public Submission() {
	}
	
	

}
