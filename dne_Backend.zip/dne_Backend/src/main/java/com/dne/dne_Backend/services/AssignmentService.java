package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Assignment;
import com.dne.dne_Backend.repository.AssignmentRepository;



@Service
public class AssignmentService {
	
	@Autowired
	
	private AssignmentRepository assignmentRepository;
	
	public Assignment addAssignment(Assignment assignment) {
		return assignmentRepository.save(assignment);
	}
	
	public void UpdateAssignment(Assignment assignment) {
		assignmentRepository.save(assignment);
	}
	
	public void deleteAssignment(int assignmentId) {
		assignmentRepository.deleteById(assignmentId);
	}
	
	public Assignment getAssignmentById(int assignmentId) {
		return assignmentRepository.findById(assignmentId).orElse(null);
	}
	
	public List<Assignment> getAllAssignments(){
		return assignmentRepository.findAll();
	}
	

	
}
