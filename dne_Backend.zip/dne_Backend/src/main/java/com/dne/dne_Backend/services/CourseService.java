package com.dne.dne_Backend.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Course;
import com.dne.dne_Backend.repository.CourseRepository;



@Service
public class CourseService {

	@Autowired
	private CourseRepository courseRepository;
	
	public List<Course> getAllCourse(){
		return courseRepository.findAll();
	}

	public Course addCourse(Course course) {
		return courseRepository.save(course);
	}
	
	public void UpdateCourse(Course course) {
		courseRepository.save(course);
	}
	
	public void deleteCourse(int courseId) {
		courseRepository.deleteById(courseId);
	}
	
	public Course getCourseById(int courseId) {
		return courseRepository.findById(courseId).orElse(null);
	}
	
	public List<Course> getAllCourses(){
		return courseRepository.findAll();
	}
	
}
