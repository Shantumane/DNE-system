package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Submission;
import com.dne.dne_Backend.repository.SubmissionRepository;



@Service
public class SubmissionService {
	
	
	@Autowired
    private SubmissionRepository submissionRepository;
	
	public List<Submission> getAllAttendance(){
		return submissionRepository.findAll();
	}

	public Submission addSubmission(Submission submission) {
		return submissionRepository.save(submission);
	}
	
	public void UpdateSubmission(Submission submission) {
		submissionRepository.save(submission);
	}
	
	public void deleteSubmission(int submissionId) {
		submissionRepository.deleteById(submissionId);
	}
	
	public Submission getSubmissionById(int submissionId) {
		return submissionRepository.findById(submissionId).orElse(null);
	}
	
	public List<Submission> getAllSubmissions(){
		return submissionRepository.findAll();
	}
	
}
