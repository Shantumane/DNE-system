package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Grade;
import com.dne.dne_Backend.repository.GradeRepository;



@Service

public class GradeService {

	@Autowired
	private GradeRepository gradeRepository;
	
	public List<Grade> getAllGrade(){
		return gradeRepository.findAll();
	}

	public Grade addGrade(Grade grade) {
		return gradeRepository.save(grade);
	}
	
	public void UpdateGrade(Grade grade) {
		gradeRepository.save(grade);
	}
	
	public void deleteGrade(int gradeId) {
		gradeRepository.deleteById(gradeId);
	}
	
	public Grade getGradeById(int gradeId) {
		return gradeRepository.findById(gradeId).orElse(null);
	}
	
	public List<Grade> getAllGrades(){
		return gradeRepository.findAll();
	}
}
