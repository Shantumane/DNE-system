package com.dne.dne_Backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dne.dne_Backend.entity.Assignment;
import com.dne.dne_Backend.services.AssignmentService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")


public class AssignmentController {

	@Autowired
    private AssignmentService assignmentService;

    @PostMapping("/assignments")
    public void addAssignment(@RequestBody Assignment assignment) {
    	assignmentService.addAssignment(assignment);
    }

    @PutMapping("/{assignmentId}")
    public void updateAssignment(@PathVariable int assignmentId, @RequestBody Assignment assignment) {
    	assignment.setAssignmentId(assignmentId);
        assignmentService.UpdateAssignment(assignment);
    }

    @DeleteMapping("/{assignmentId}")
    public void deleteAssignment(@PathVariable int assignmentId) {
    	assignmentService.deleteAssignment(assignmentId);
    }

    @GetMapping("/{assignmentId}")
    public Assignment getAssignmentById(@PathVariable int assignmentId) {
        return assignmentService.getAssignmentById(assignmentId);
    }

    @GetMapping("/assignment")
    public List<Assignment> getAllAssignments() {
        return assignmentService.getAllAssignments();
    }
}
