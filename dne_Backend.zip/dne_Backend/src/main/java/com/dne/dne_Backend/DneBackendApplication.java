package com.dne.dne_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DneBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DneBackendApplication.class, args);
	}

}



