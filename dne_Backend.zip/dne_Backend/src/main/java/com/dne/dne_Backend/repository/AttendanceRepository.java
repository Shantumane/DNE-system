package com.dne.dne_Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dne.dne_Backend.entity.Attendance;


@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {

}
