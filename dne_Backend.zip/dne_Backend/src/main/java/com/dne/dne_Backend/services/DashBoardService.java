package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.DashBoard;
import com.dne.dne_Backend.repository.DashBoardRepository;



@Service
public class DashBoardService {

	@Autowired
	
	private DashBoardRepository dashBoardRepository;
	
	public List<DashBoard> getAllDashBoard(){
		return dashBoardRepository.findAll();
	}

	public DashBoard addDashBoard(DashBoard dashBoard) {
		return dashBoardRepository.save(dashBoard);
	}
	
	public void UpdateDashBoard(DashBoard dashBoard) {
		dashBoardRepository.save(dashBoard);
	}
	
	public void deleteDashBoard(int dashBoardId) {
		dashBoardRepository.deleteById(dashBoardId);
	}
	
	public DashBoard getDashBoardById(int dashBoardId) {
		return dashBoardRepository.findById(dashBoardId).orElse(null);
	}
	
	public List<DashBoard> getAllDashBoards(){
		return dashBoardRepository.findAll();
	}
}
