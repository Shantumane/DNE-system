package com.dne.dne_Backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dne.dne_Backend.entity.Attendance;
import com.dne.dne_Backend.repository.AttendanceRepository;



@Service
public class AttendanceService {
	
	@Autowired
	
	private AttendanceRepository attendanceRepository;
	
	public List<Attendance> getAllAttendance(){
		return attendanceRepository.findAll();
	}

	public Attendance addAttendance(Attendance attendance) {
		return attendanceRepository.save(attendance);
	}
	
	public void UpdateAttendance(Attendance attendance) {
		attendanceRepository.save(attendance);
	}
	
	public void deleteAttendance(int attendanceId) {
		attendanceRepository.deleteById(attendanceId);
	}
	
	public Attendance getAttendanceById(int attendanceId) {
		return attendanceRepository.findById(attendanceId).orElse(null);
	}
	
	public List<Attendance> getAllAttendances(){
		return attendanceRepository.findAll();
	}
	
	

}
