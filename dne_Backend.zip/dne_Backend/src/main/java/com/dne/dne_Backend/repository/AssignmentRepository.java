package com.dne.dne_Backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dne.dne_Backend.entity.Assignment;


@Repository
public interface  AssignmentRepository extends JpaRepository<Assignment, Integer> {

	List<Assignment> findAll();

}

