package com.dne.dne_Backend.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Resource {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resourceId;
	private int courseId;
	private String resourseName;
	private String resourseType;
	private String resourseLink;
	
	
	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getResourseName() {
		return resourseName;
	}
	public void setResourseName(String resourseName) {
		this.resourseName = resourseName;
	}
	public String getResourseType() {
		return resourseType;
	}
	public void setResourseType(String resourseType) {
		this.resourseType = resourseType;
	}
	public String getResourseLink() {
		return resourseLink;
	}
	public void setResourseLink(String resourseLink) {
		this.resourseLink = resourseLink;
	}
	public Resource(int resourceId, int courseId, String resourseName, String resourseType, String resourseLink) {
		this.resourceId = resourceId;
		this.courseId = courseId;
		this.resourseName = resourseName;
		this.resourseType = resourseType;
		this.resourseLink = resourseLink;
	}
	public Resource() {
	}
	
	
	
	

}
