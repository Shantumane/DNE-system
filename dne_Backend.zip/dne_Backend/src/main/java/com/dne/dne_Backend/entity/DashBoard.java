package com.dne.dne_Backend.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class DashBoard {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int userId;
	private String dashboardLayout;
	private List<String> recentlyAccessed;
	private List<String> upcomingAssignment;
	private List<String> announcements;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getDashboardLayout() {
		return dashboardLayout;
	}
	public void setDashboardLayout(String dashboardLayout) {
		this.dashboardLayout = dashboardLayout;
	}
	public List<String> getRecentlyAccessed() {
		return recentlyAccessed;
	}
	public void setRecentlyAccessed(List<String> recentlyAccessed) {
		this.recentlyAccessed = recentlyAccessed;
	}
	public List<String> getUpcomingAssignment() {
		return upcomingAssignment;
	}
	public void setUpcomingAssignment(List<String> upcomingAssignment) {
		this.upcomingAssignment = upcomingAssignment;
	}
	public List<String> getAnnouncements() {
		return announcements;
	}
	public void setAnnouncements(List<String> announcements) {
		this.announcements = announcements;
	}
	public DashBoard(int userId, String dashboardLayout, List<String> recentlyAccessed, List<String> upcomingAssignment,
			List<String> announcements) {
		
		this.userId = userId;
		this.dashboardLayout = dashboardLayout;
		this.recentlyAccessed = recentlyAccessed;
		this.upcomingAssignment = upcomingAssignment;
		this.announcements = announcements;
	}
	public DashBoard() {
		
	}
	
	
	
	

}
