package com.dne.dne_Backend.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Enrollment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int enrollmentId;
	private int courseId;
	private int studentId;
	private Date enrollmentDate;
	
	public int getEnrollmentId() {
		return enrollmentId;
	}
	
	public void setEnrollmentId(int enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	
	public int getCourseId() {
		return courseId;
	}
	
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	public int getStudentId() {
		return studentId;
	}
	
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public Date getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(Date enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	public Enrollment(int enrollmentId, int courseId, int studentId, Date enrollmentDate) {
		this.enrollmentId = enrollmentId;
		this.courseId = courseId;
		this.studentId = studentId;
		this.enrollmentDate = enrollmentDate;
	}

	public Enrollment() {
	}
	
	

}
