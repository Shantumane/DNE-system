package com.dne.dne_Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dne.dne_Backend.entity.DashBoard;



@Repository
public interface DashBoardRepository extends JpaRepository<DashBoard, Integer> {

}
